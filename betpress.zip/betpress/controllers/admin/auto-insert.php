<?php

//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}

function betpress_auto_insert_controller() {
    
    if (isset($_POST['inserting_xml_data'])) {
        
        $sport_id = (int) betpress_sanitize($_POST['sport_id']);
        
        $events = isset($_POST['events']) ? $_POST['events'] : null;
        
        $bet_events = isset($_POST['bet_events']) ? $_POST['bet_events'] : null;
        
        $cats = isset($_POST['categories']) ? $_POST['categories'] : null;
        
        $errors = array();
        
        if (0 === $sport_id) {
            
            $errors [] = __('No sport selected.', 'BetPress');
        }
        
        if ( ! is_array($events) ) {
            
            $errors [] = __('No events selected.', 'BetPress');
            
        } else {
            
            $events_filtered = array();
            
            foreach ($events as $key => $event) {
                
                $events_filtered [$key] = explode('/', betpress_sanitize($event));
                
                if (count($events_filtered[$key]) != 2) {
                    
                    $errors [] = __('Invalid data passed.', 'BetPress');
                    
                }
            }
        }
        
        if ( ! is_array($bet_events) ) {
            
            $errors [] = __('No bet events selected.', 'BetPress');
            
        } else {
            
            $bet_events_filtered = array();
            
            foreach ($bet_events as $key => $bet_event) {
                
                $bet_events_filtered [$key] = explode('/', betpress_sanitize($bet_event));
                
                if (count($bet_events_filtered[$key]) != 2) {
                    
                    $errors [] = __('Invalid data passed.', 'BetPress');
                    
                }
            }
        }
        
        if ( ! is_array($cats) ) {
            
            $errors [] = __('No categories selected.', 'BetPress');
            
        } else {
            
            $cats_filtered = array();
            
            foreach ($cats as $key => $cat) {
                
                $cats_filtered [$key] = explode('/', betpress_sanitize($cat));
                
                if (count($cats_filtered[$key]) != 2) {
                    
                    $errors [] = __('Invalid data passed.', 'BetPress');
                    
                }
            }
        }
        
        if ( ! empty($errors) ) {
            
            foreach ($errors as $err) {
                
                $pass['error_message'] = $err;
                betpress_get_view('error-message', 'admin', $pass);
                
            }
            
        } else {
        
            $data = array();
            
            foreach ($events_filtered as $event) {

                if ($event[1] == $sport_id) {

                    $data [$event[1]] [$event[0]] = array();

                    foreach ($bet_events_filtered as $bet_event) {

                        if ($bet_event[1] == $event[0]) {

                            $data [$event[1]] [$bet_event[1]] [$bet_event[0]] = array();

                            foreach ($cats_filtered as $cat) {
                                
                                if ($cat[1] == $bet_event[0]) {

                                    $data [$event[1]] [$bet_event[1]] [$cat[1]] [$cat[0]] = array();
                                    
                                }
                            }
                        }
                    }
                }
            }
            
            $is_active = isset($_POST['auto_activate']) ? 1 : 0;

            if (betpress_insert_specific_xml_data($data, $is_active) === true) {
                
                $pass['update_message'] = __('Selected data was inserted.', 'BetPress');
                betpress_get_view('updated-message', 'admin', $pass);
                
            } else {
                
                $pass['error_message'] = __('Database error.', 'BetPress');
                betpress_get_view('error-message', 'admin', $pass);
                
            }
        }
    }
    
    $pass['xml_data'] = betpress_get_xml_data();
    betpress_get_view('auto-insert', 'admin', $pass);
    
}
